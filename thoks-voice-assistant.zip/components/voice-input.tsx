"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { Mic, MicOff, Keyboard, Send } from "lucide-react"

interface VoiceInputProps {
  isListening: boolean
  isWakeWordHeard: boolean
  onSpeechInput: (speech: string) => void
  userSpeech: string
}

export function VoiceInput({ isListening, isWakeWordHeard, onSpeechInput, userSpeech }: VoiceInputProps) {
  const recognitionRef = useRef<any | null>(null)
  const [speechSupported, setSpeechSupported] = useState(false)
  const [manualInput, setManualInput] = useState("")
  const [showManualInput, setShowManualInput] = useState(false)

  useEffect(() => {
    // Check if we're in browser environment and speech recognition is supported
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition
      setSpeechSupported(!!SpeechRecognition)

      if (SpeechRecognition) {
        const recognition = new SpeechRecognition()

        recognition.continuous = false
        recognition.interimResults = true
        recognition.lang = "en-US"

        recognition.onresult = (event: any) => {
          const transcript = Array.from(event.results)
            .map((result: any) => result[0])
            .map((result: any) => result.transcript)
            .join("")

          if (event.results[0].isFinal) {
            onSpeechInput(transcript)
          }
        }

        recognition.onerror = (event: any) => {
          console.error("Speech recognition error:", event.error)
        }

        recognitionRef.current = recognition
      }
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop()
        } catch (error) {
          console.error("Error stopping speech recognition:", error)
        }
      }
    }
  }, [onSpeechInput])

  useEffect(() => {
    if (speechSupported && isListening && recognitionRef.current) {
      try {
        recognitionRef.current.start()
      } catch (error) {
        console.error("Error starting speech recognition:", error)
      }
    } else if (recognitionRef.current) {
      try {
        recognitionRef.current.stop()
      } catch (error) {
        console.error("Error stopping speech recognition:", error)
      }
    }
  }, [isListening, speechSupported])

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (manualInput.trim()) {
      onSpeechInput(manualInput.trim())
      setManualInput("")
      setShowManualInput(false)
    }
  }

  const handleActivateManualInput = () => {
    setShowManualInput(true)
  }

  return (
    <div className="text-center">
      <div className="relative inline-block">
        {/* Microphone visualization or manual input button */}
        <div
          className={`w-32 h-32 rounded-full border-2 border-cyan-400 flex items-center justify-center relative ${
            isListening ? "animate-pulse bg-cyan-400/20" : "bg-cyan-400/10"
          }`}
        >
          {/* Ripple effect when listening */}
          {isListening && speechSupported && (
            <>
              <div className="absolute inset-0 rounded-full border-2 border-cyan-400 animate-ping opacity-75"></div>
              <div
                className="absolute inset-0 rounded-full border-2 border-cyan-400 animate-ping opacity-50"
                style={{ animationDelay: "0.5s" }}
              ></div>
            </>
          )}

          {speechSupported ? (
            isListening ? (
              <Mic className="w-12 h-12 text-cyan-400" />
            ) : (
              <MicOff className="w-12 h-12 text-cyan-400/50" />
            )
          ) : (
            <button
              onClick={handleActivateManualInput}
              className="w-12 h-12 text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <Keyboard className="w-12 h-12" />
            </button>
          )}
        </div>

        {/* Voice level indicator */}
        {isListening && speechSupported && (
          <div className="mt-4 flex justify-center space-x-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="w-2 bg-cyan-400 rounded-full animate-pulse"
                style={{
                  height: `${Math.random() * 20 + 10}px`,
                  animationDelay: `${i * 0.1}s`,
                }}
              ></div>
            ))}
          </div>
        )}

        {/* Manual input mode indicator */}
        {!speechSupported && <div className="mt-4 text-sm text-cyan-400/80 font-mono">CLICK TO TYPE YOUR MESSAGE</div>}
      </div>

      {/* Manual input form */}
      {showManualInput && (
        <div className="mt-6 p-4 bg-cyan-900/20 border border-cyan-400/30 rounded-lg backdrop-blur-sm">
          <form onSubmit={handleManualSubmit} className="flex space-x-2">
            <input
              type="text"
              value={manualInput}
              onChange={(e) => setManualInput(e.target.value)}
              placeholder="Type your message to THOKS..."
              className="flex-1 bg-black/50 border border-cyan-400/30 rounded px-3 py-2 text-cyan-300 placeholder-cyan-400/50 focus:outline-none focus:border-cyan-400"
              autoFocus
            />
            <button
              type="submit"
              disabled={!manualInput.trim()}
              className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-600 disabled:to-gray-700 rounded transition-all duration-300"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* Speech transcript */}
      {userSpeech && (
        <div className="mt-6 p-4 bg-cyan-900/20 border border-cyan-400/30 rounded-lg backdrop-blur-sm">
          <p className="text-cyan-300 font-mono text-sm">
            <span className="text-cyan-500">USER:</span> {userSpeech}
          </p>
        </div>
      )}

      {/* Speech support status */}
      {!speechSupported && (
        <div className="mt-4 p-3 bg-yellow-900/20 border border-yellow-400/30 rounded-lg backdrop-blur-sm">
          <p className="text-yellow-300 text-sm font-mono">Voice input not available - using text input mode</p>
        </div>
      )}
    </div>
  )
}
