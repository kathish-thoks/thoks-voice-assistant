"use client"

import { useEffect, useState } from "react"
import { AlertTriangle } from "lucide-react"

export function BrowserCompatibility() {
  const [isSupported, setIsSupported] = useState(true)

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    setIsSupported(!!SpeechRecognition)
  }, [])

  if (isSupported) return null

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-red-900/20 border border-red-400/30 rounded-lg p-8 max-w-md mx-4 text-center">
        <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-red-300 mb-4">Browser Not Supported</h2>
        <p className="text-red-400/80 mb-6">
          THOKS requires a browser with Web Speech API support. Please use Chrome, Edge, or Safari for the best
          experience.
        </p>
        <div className="text-sm text-red-500 font-mono">Supported browsers: Chrome, Edge, Safari</div>
      </div>
    </div>
  )
}
