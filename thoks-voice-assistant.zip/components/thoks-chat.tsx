"use client"

import { Bot, User, AlertTriangle } from "lucide-react"

interface ThoksChatProps {
  userMessage: string
  aiResponse: string
  isProcessing: boolean
  apiStatus?: "normal" | "fallback" | "error"
}

export function ThoksChat({ userMessage, aiResponse, isProcessing, apiStatus = "normal" }: ThoksChatProps) {
  return (
    <div className="space-y-4">
      {/* User message */}
      {userMessage && (
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
            <User className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 bg-blue-900/20 border border-blue-400/30 rounded-lg p-4 backdrop-blur-sm">
            <p className="text-blue-300">{userMessage}</p>
          </div>
        </div>
      )}

      {/* AI response */}
      <div className="flex items-start space-x-3">
        <div
          className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 animate-pulse ${
            apiStatus === "normal"
              ? "bg-gradient-to-r from-cyan-500 to-purple-500"
              : apiStatus === "fallback"
                ? "bg-gradient-to-r from-yellow-500 to-orange-500"
                : "bg-gradient-to-r from-red-500 to-pink-500"
          }`}
        >
          {apiStatus !== "normal" ? (
            <AlertTriangle className="w-4 h-4 text-white" />
          ) : (
            <Bot className="w-4 h-4 text-white" />
          )}
        </div>
        <div
          className={`flex-1 rounded-lg p-4 backdrop-blur-sm ${
            apiStatus === "normal"
              ? "bg-cyan-900/20 border border-cyan-400/30"
              : apiStatus === "fallback"
                ? "bg-yellow-900/20 border border-yellow-400/30"
                : "bg-red-900/20 border border-red-400/30"
          }`}
        >
          {isProcessing ? (
            <div className="flex items-center space-x-2">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                <div
                  className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.1s" }}
                ></div>
                <div
                  className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                ></div>
              </div>
              <span className="text-cyan-300 font-mono text-sm">THOKS is thinking...</span>
            </div>
          ) : aiResponse ? (
            <>
              <p
                className={
                  apiStatus === "normal"
                    ? "text-cyan-300"
                    : apiStatus === "fallback"
                      ? "text-yellow-300"
                      : "text-red-300"
                }
              >
                {aiResponse}
              </p>
              {apiStatus !== "normal" && (
                <div className="mt-2 text-xs font-mono opacity-70">
                  {apiStatus === "fallback" ? "Response from backup systems" : "Limited functionality mode"}
                </div>
              )}
            </>
          ) : null}
        </div>
      </div>
    </div>
  )
}
