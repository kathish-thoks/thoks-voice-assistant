"use client"

import { Search, ExternalLink, AlertCircle, CheckCircle } from "lucide-react"

interface SearchResult {
  title: string
  url: string
  snippet: string
}

interface SearchResultsProps {
  results: {
    query: string
    results: SearchResult[]
    source?: string
    note?: string
    error?: string
  }
}

export function SearchResults({ results }: SearchResultsProps) {
  if (!results?.results?.length) return null

  const getStatusIcon = () => {
    if (results.error) return <AlertCircle className="w-5 h-5 text-red-400" />
    if (results.source === "Mock Results") return <AlertCircle className="w-5 h-5 text-yellow-400" />
    return <CheckCircle className="w-5 h-5 text-green-400" />
  }

  const getStatusColor = () => {
    if (results.error) return "border-red-400/30 bg-red-900/20"
    if (results.source === "Mock Results") return "border-yellow-400/30 bg-yellow-900/20"
    return "border-purple-400/30 bg-purple-900/20"
  }

  return (
    <div className={`rounded-lg p-6 backdrop-blur-sm ${getStatusColor()}`}>
      <div className="flex items-center space-x-2 mb-4">
        <Search className="w-5 h-5 text-purple-400" />
        <h3 className="text-lg font-mono text-purple-300">Search Results</h3>
        {getStatusIcon()}
      </div>

      <div className="text-sm text-purple-400 mb-2 font-mono">Query: "{results.query}"</div>

      {results.source && (
        <div className="text-xs text-purple-500 mb-4 font-mono">
          Source: {results.source}
          {results.note && <span className="ml-2 text-yellow-400">• {results.note}</span>}
        </div>
      )}

      <div className="space-y-4">
        {results.results.slice(0, 3).map((result, index) => (
          <div
            key={index}
            className="border border-purple-400/20 rounded-lg p-4 hover:bg-purple-900/30 transition-colors"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h4 className="text-purple-300 font-medium mb-2 line-clamp-2">{result.title}</h4>
                <p className="text-purple-400/80 text-sm mb-2 line-clamp-3">{result.snippet}</p>
                <div className="flex items-center space-x-2">
                  <ExternalLink className="w-3 h-3 text-purple-500" />
                  <span className="text-purple-500 text-xs font-mono truncate">{result.url}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {results.error && (
        <div className="mt-4 p-3 bg-red-900/20 border border-red-400/30 rounded-lg">
          <p className="text-red-300 text-sm font-mono">{results.error}</p>
        </div>
      )}
    </div>
  )
}
