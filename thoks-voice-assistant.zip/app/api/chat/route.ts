import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

// Fallback responses for when OpenAI API is unavailable
const fallbackResponses = {
  greeting: [
    "Hello! I'm THOKS, your AI assistant. I'm currently running in offline mode, but I can still help you with basic responses.",
    "Greetings! THOKS here. My main AI systems are temporarily offline, but I'm still operational in basic mode.",
    "Hi there! I'm THOKS. While my advanced AI is currently unavailable, I can still assist you with simple queries.",
  ],
  search: [
    "I understand you want to search for information. While my AI is offline, I can still attempt to find web results for you.",
    "Search request received. I'll try to find relevant information using available search systems.",
    "I'll help you search for that information using my backup search capabilities.",
  ],
  general: [
    "I'm currently operating in limited mode due to API constraints. I can still help with basic tasks and searches.",
    "My advanced AI systems are temporarily unavailable, but I'm still here to assist you as best I can.",
    "I'm running in backup mode right now. While my responses may be simpler, I can still try to help you.",
    "THOKS systems are operating at reduced capacity. I can still process your requests using alternative methods.",
  ],
  error: [
    "I'm experiencing some technical difficulties with my main AI systems. Let me try to help you another way.",
    "My primary AI is currently offline. I'm switching to backup systems to assist you.",
    "There seems to be an issue with my advanced processing. I'll do my best to help with available resources.",
  ],
}

function getFallbackResponse(message: string): string {
  const lowerMessage = message.toLowerCase()

  if (lowerMessage.includes("hello") || lowerMessage.includes("hi") || lowerMessage.includes("hey")) {
    return fallbackResponses.greeting[Math.floor(Math.random() * fallbackResponses.greeting.length)]
  }

  if (lowerMessage.includes("search") || lowerMessage.includes("find") || lowerMessage.includes("look up")) {
    return fallbackResponses.search[Math.floor(Math.random() * fallbackResponses.search.length)]
  }

  return fallbackResponses.general[Math.floor(Math.random() * fallbackResponses.general.length)]
}

export async function POST(request: Request) {
  try {
    const { message } = await request.json()

    // Try OpenAI API first
    const { text } = await generateText({
      model: openai("gpt-4o-mini"),
      system: `You are THOKS, an advanced AI voice assistant with a sci-fi personality. 
      You are helpful, intelligent, and slightly futuristic in your responses. 
      Keep responses concise but informative, as they will be spoken aloud. 
      Use a confident, tech-savvy tone that fits a sci-fi interface.`,
      prompt: message,
    })

    return Response.json({ response: text })
  } catch (error) {
    console.error("Chat API error:", error)

    // Check if it's a quota/billing error
    const errorMessage = error instanceof Error ? error.message : String(error)

    if (errorMessage.includes("quota") || errorMessage.includes("billing") || errorMessage.includes("exceeded")) {
      // Use fallback response for quota errors
      const fallbackText = getFallbackResponse(request.body ? await request.json().then((data) => data.message) : "")

      return Response.json({
        response: fallbackText,
        fallback: true,
        error: "API quota exceeded - using backup responses",
      })
    }

    // For other errors, provide a generic fallback
    const errorResponse = fallbackResponses.error[Math.floor(Math.random() * fallbackResponses.error.length)]

    return Response.json({
      response: errorResponse,
      fallback: true,
      error: "API temporarily unavailable",
    })
  }
}
