export async function POST(request: Request) {
  try {
    const { query } = await request.json()

    if (!process.env.SEARCH_API_KEY) {
      return Response.json({
        query,
        results: [
          {
            title: "Search API not configured",
            url: "https://example.com",
            snippet: "Please configure SEARCH_API_KEY environment variable to enable web search functionality.",
          },
        ],
      })
    }

    // Try multiple search API formats to ensure compatibility
    let searchUrl: string
    let response: Response

    // First try SearchAPI.io format
    try {
      searchUrl = `https://www.searchapi.io/api/v1/search?engine=google&q=${encodeURIComponent(query)}&api_key=${process.env.SEARCH_API_KEY}`

      response = await fetch(searchUrl, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()

        const results =
          data.organic_results?.slice(0, 5).map((result: any) => ({
            title: result.title || "No title",
            url: result.link || result.url || "#",
            snippet: result.snippet || result.description || "No description available",
          })) || []

        return Response.json({
          query,
          results,
          source: "SearchAPI.io",
        })
      }
    } catch (error) {
      console.log("SearchAPI.io failed, trying alternative format...")
    }

    // Try alternative API format (SerpAPI style)
    try {
      searchUrl = `https://serpapi.com/search.json?engine=google&q=${encodeURIComponent(query)}&api_key=${process.env.SEARCH_API_KEY}`

      response = await fetch(searchUrl, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()

        const results =
          data.organic_results?.slice(0, 5).map((result: any) => ({
            title: result.title || "No title",
            url: result.link || result.url || "#",
            snippet: result.snippet || result.description || "No description available",
          })) || []

        return Response.json({
          query,
          results,
          source: "SerpAPI",
        })
      }
    } catch (error) {
      console.log("SerpAPI failed, trying Google Custom Search...")
    }

    // Try Google Custom Search API format
    try {
      searchUrl = `https://www.googleapis.com/customsearch/v1?key=${process.env.SEARCH_API_KEY}&cx=YOUR_SEARCH_ENGINE_ID&q=${encodeURIComponent(query)}`

      response = await fetch(searchUrl, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()

        const results =
          data.items?.slice(0, 5).map((result: any) => ({
            title: result.title || "No title",
            url: result.link || "#",
            snippet: result.snippet || result.description || "No description available",
          })) || []

        return Response.json({
          query,
          results,
          source: "Google Custom Search",
        })
      }
    } catch (error) {
      console.log("Google Custom Search failed...")
    }

    // If all APIs fail, provide mock results for demonstration
    const mockResults = [
      {
        title: `Search results for: ${query}`,
        url: "https://example.com",
        snippet: `I found some information related to "${query}". While I can't access live search results right now, I can still help you with general information about this topic.`,
      },
      {
        title: "THOKS Search System",
        url: "https://example.com/search",
        snippet:
          "My search capabilities are currently limited, but I'm working to provide you with the best possible assistance.",
      },
      {
        title: "Alternative Information Sources",
        url: "https://example.com/info",
        snippet:
          "You might want to try searching directly on Google, Bing, or other search engines for the most current information.",
      },
    ]

    return Response.json({
      query,
      results: mockResults,
      source: "Mock Results",
      note: "Search API temporarily unavailable - showing example results",
    })
  } catch (error) {
    console.error("Search API error:", error)

    // Provide helpful fallback results even on complete failure
    const fallbackResults = [
      {
        title: "Search System Offline",
        url: "https://example.com",
        snippet:
          "I'm having trouble accessing search results right now, but I'm still here to help with questions and conversations.",
      },
      {
        title: "THOKS Assistant",
        url: "https://example.com/help",
        snippet:
          "While search is temporarily unavailable, you can still ask me questions and I'll do my best to provide helpful responses.",
      },
    ]

    return Response.json({
      query: "",
      results: fallbackResults,
      source: "Fallback",
      error: "Search functionality temporarily unavailable",
    })
  }
}
