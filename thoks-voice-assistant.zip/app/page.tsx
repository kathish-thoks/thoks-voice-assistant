"use client"

import { useState, useEffect } from "react"
import { ThoksChat } from "@/components/thoks-chat"
import { VoiceInput } from "@/components/voice-input"
import { SearchResults } from "@/components/search-results"
import { useWakeWord } from "@/hooks/use-wake-word"
import { useVoicePlayback } from "@/hooks/use-voice-playback"

export default function Home() {
  const [isWakeWordHeard, setIsWakeWordHeard] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [userSpeech, setUserSpeech] = useState("")
  const [aiTextReply, setAiTextReply] = useState("")
  const [searchResults, setSearchResults] = useState(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [apiStatus, setApiStatus] = useState<"normal" | "fallback" | "error">("normal")

  const {
    startListening: startWakeWordListening,
    stopListening: stopWakeWordListening,
    speechSupported,
  } = useWakeWord({
    onWakeWordDetected: () => {
      setIsWakeWordHeard(true)
      setIsListening(true)
    },
  })

  const { playVoice, isPlaying } = useVoicePlayback()

  useEffect(() => {
    // Start listening for wake word on mount if speech is supported
    if (speechSupported) {
      startWakeWordListening()
    }

    return () => {
      stopWakeWordListening()
    }
  }, [startWakeWordListening, stopWakeWordListening, speechSupported])

  const handleSpeechInput = async (speech: string) => {
    setUserSpeech(speech)
    setIsProcessing(true)

    try {
      // Check if it's a search query
      const isSearchQuery =
        speech.toLowerCase().includes("search") ||
        speech.toLowerCase().includes("find") ||
        speech.toLowerCase().includes("look up")

      if (isSearchQuery) {
        // Perform search first
        try {
          const searchResponse = await fetch("/api/search", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query: speech }),
          })
          const searchData = await searchResponse.json()
          setSearchResults(searchData)

          // Generate AI response about search results
          const aiResponse = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: `Based on these search results: ${JSON.stringify(searchData.results?.slice(0, 3))}, provide a helpful summary for the user's query: "${speech}"`,
            }),
          })
          const aiData = await aiResponse.json()

          // Check if we're using fallback mode
          if (aiData.fallback) {
            setApiStatus("fallback")
          } else {
            setApiStatus("normal")
          }

          setAiTextReply(aiData.response)

          // Play voice response
          await playVoice(aiData.response)
        } catch (error) {
          console.error("Search error:", error)
          setAiTextReply(
            "I found some search results, but I'm having trouble processing them right now. You can see the results below.",
          )
          setApiStatus("error")
        }
      } else {
        // Regular chat
        try {
          const response = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: speech }),
          })
          const data = await response.json()

          // Check if we're using fallback mode
          if (data.fallback) {
            setApiStatus("fallback")
          } else {
            setApiStatus("normal")
          }

          setAiTextReply(data.response)

          // Play voice response
          await playVoice(data.response)
        } catch (error) {
          console.error("Chat error:", error)
          setAiTextReply("I'm experiencing some technical difficulties. My backup systems are working to assist you.")
          setApiStatus("error")
        }
      }
    } catch (error) {
      console.error("Error processing speech:", error)
      setAiTextReply("Sorry, I encountered an error processing your request. Please try again.")
      setApiStatus("error")
    } finally {
      setIsProcessing(false)
      setIsListening(false)
      setIsWakeWordHeard(false)

      // Resume wake word listening after a delay if speech is supported
      if (speechSupported) {
        setTimeout(() => {
          startWakeWordListening()
        }, 2000)
      }
    }
  }

  const resetSession = () => {
    setIsWakeWordHeard(false)
    setIsListening(false)
    setUserSpeech("")
    setAiTextReply("")
    setSearchResults(null)
    setIsProcessing(false)
    setApiStatus("normal")
    if (speechSupported) {
      startWakeWordListening()
    }
  }

  const handleManualActivation = () => {
    if (!speechSupported) {
      setIsWakeWordHeard(true)
      setIsListening(true)
    }
  }

  return (
    <div className="min-h-screen bg-black text-cyan-400 overflow-hidden relative">
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-purple-900/20 to-cyan-900/20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,255,255,0.1),transparent_50%)] animate-pulse"></div>
      </div>

      {/* Grid overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,255,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,255,0.1)_1px,transparent_1px)] bg-[size:50px_50px]"></div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 animate-pulse">
            THOKS
          </h1>
          <p className="text-xl text-cyan-300/80 font-mono">Advanced Voice Assistant Interface</p>

          {/* API Status indicator */}
          {apiStatus !== "normal" && (
            <div
              className={`mt-2 px-4 py-2 rounded-lg text-sm font-mono ${
                apiStatus === "fallback"
                  ? "bg-yellow-900/20 border border-yellow-400/30 text-yellow-300"
                  : "bg-red-900/20 border border-red-400/30 text-red-300"
              }`}
            >
              {apiStatus === "fallback"
                ? "BACKUP MODE - Limited AI functionality"
                : "REDUCED FUNCTIONALITY - Some systems offline"}
            </div>
          )}

          {/* Status indicator */}
          <div className="mt-6 flex justify-center items-center space-x-4">
            <div
              className={`w-4 h-4 rounded-full ${
                isWakeWordHeard
                  ? "bg-green-400 animate-pulse"
                  : isListening
                    ? "bg-yellow-400 animate-pulse"
                    : apiStatus === "normal"
                      ? "bg-cyan-400/50"
                      : "bg-orange-400/50"
              } shadow-lg`}
            ></div>
            <span className="text-sm font-mono">
              {isProcessing
                ? "PROCESSING..."
                : isPlaying
                  ? "SPEAKING..."
                  : isWakeWordHeard
                    ? "LISTENING..."
                    : speechSupported
                      ? 'STANDBY - SAY "THOKS" TO ACTIVATE'
                      : "READY - CLICK TO START"}
            </span>
          </div>

          {/* Manual activation button for non-speech environments */}
          {!speechSupported && !isWakeWordHeard && (
            <div className="mt-4">
              <button
                onClick={handleManualActivation}
                className="px-6 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-lg font-mono text-sm transition-all duration-300 transform hover:scale-105 shadow-lg shadow-cyan-500/25"
              >
                ACTIVATE THOKS
              </button>
            </div>
          )}
        </div>

        {/* Main interface */}
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Voice Input Component */}
          <VoiceInput
            isListening={isListening}
            isWakeWordHeard={isWakeWordHeard}
            onSpeechInput={handleSpeechInput}
            userSpeech={userSpeech}
          />

          {/* Chat Interface */}
          {(userSpeech || aiTextReply) && (
            <ThoksChat userMessage={userSpeech} aiResponse={aiTextReply} isProcessing={isProcessing} />
          )}

          {/* Search Results */}
          {searchResults && <SearchResults results={searchResults} />}

          {/* Reset button */}
          {(userSpeech || aiTextReply) && (
            <div className="text-center">
              <button
                onClick={resetSession}
                className="px-6 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-lg font-mono text-sm transition-all duration-300 transform hover:scale-105 shadow-lg shadow-cyan-500/25"
              >
                NEW SESSION
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Floating particles effect */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400/30 rounded-full animate-ping"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`,
            }}
          ></div>
        ))}
      </div>
    </div>
  )
}
