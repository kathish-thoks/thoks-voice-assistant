"use client"

import { useState, useCallback } from "react"

export function useVoicePlayback() {
  const [isPlaying, setIsPlaying] = useState(false)

  const playVoice = useCallback(async (text: string) => {
    if (!text) return

    setIsPlaying(true)

    try {
      const response = await fetch("/api/voice", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      })

      if (!response.ok) {
        throw new Error("Voice generation failed")
      }

      const audioBlob = await response.blob()
      const audioUrl = URL.createObjectURL(audioBlob)
      const audio = new Audio(audioUrl)

      audio.onended = () => {
        setIsPlaying(false)
        URL.revokeObjectURL(audioUrl)
      }

      audio.onerror = () => {
        setIsPlaying(false)
        URL.revokeObjectURL(audioUrl)
      }

      await audio.play()
    } catch (error) {
      console.error("Voice playback error:", error)
      setIsPlaying(false)
    }
  }, [])

  return { playVoice, isPlaying }
}
