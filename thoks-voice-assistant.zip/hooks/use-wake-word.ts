"use client"

import { useRef, useCallback, useState, useEffect } from "react"

interface UseWakeWordProps {
  onWakeWordDetected: () => void
  wakeWord?: string
}

export function useWakeWord({ onWakeWordDetected, wakeWord = "thoks" }: UseWakeWordProps) {
  const recognitionRef = useRef<any | null>(null)
  const isListeningRef = useRef(false)
  const [speechSupported, setSpeechSupported] = useState(false)

  useEffect(() => {
    // Check if we're in browser environment and speech recognition is supported
    if (typeof window !== "undefined") {
      const SpeechRecognitionImpl = window.SpeechRecognition || (window as any).webkitSpeechRecognition
      setSpeechSupported(!!SpeechRecognitionImpl)
    }
  }, [])

  const startListening = useCallback(() => {
    if (!speechSupported) {
      console.log("Speech recognition not supported - wake word detection disabled")
      return
    }

    // Check if speech recognition is supported
    const SpeechRecognitionImpl = window.SpeechRecognition || (window as any).webkitSpeechRecognition

    if (!SpeechRecognitionImpl) {
      console.error("Speech recognition not supported in this browser")
      return
    }

    if (isListeningRef.current) return

    const recognition = new SpeechRecognitionImpl()

    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = "en-US"

    recognition.onstart = () => {
      isListeningRef.current = true
      console.log("Wake word detection started")
    }

    recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results)
        .map((result: any) => result[0])
        .map((result: any) => result.transcript)
        .join("")
        .toLowerCase()

      console.log("Wake word listening:", transcript)

      if (transcript.includes(wakeWord.toLowerCase())) {
        console.log("Wake word detected!")
        onWakeWordDetected()
        recognition.stop()
      }
    }

    recognition.onerror = (event: any) => {
      console.error("Wake word recognition error:", event.error)
      if (event.error === "not-allowed") {
        console.error("Microphone access denied")
      }
    }

    recognition.onend = () => {
      isListeningRef.current = false
      console.log("Wake word recognition ended")
      // Auto-restart unless manually stopped
      if (recognitionRef.current === recognition) {
        setTimeout(() => {
          if (recognitionRef.current === recognition) {
            try {
              recognition.start()
            } catch (error) {
              console.error("Error restarting wake word detection:", error)
            }
          }
        }, 1000)
      }
    }

    recognitionRef.current = recognition

    try {
      recognition.start()
    } catch (error) {
      console.error("Error starting wake word detection:", error)
    }
  }, [onWakeWordDetected, wakeWord, speechSupported])

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      const recognition = recognitionRef.current
      recognitionRef.current = null
      try {
        recognition.stop()
      } catch (error) {
        console.error("Error stopping wake word detection:", error)
      }
      isListeningRef.current = false
    }
  }, [])

  return { startListening, stopListening, speechSupported }
}
